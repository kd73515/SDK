# Nacelle SDK Testbed

The SDK testbed is a web-based interface for getting responses using the Nacelle SDK. 

## Installation

Ensure you have [nvm](https://github.com/nvm-sh/nvm) installed, then run:

```
nvm use
```

followed by:

```
npm i 
```
